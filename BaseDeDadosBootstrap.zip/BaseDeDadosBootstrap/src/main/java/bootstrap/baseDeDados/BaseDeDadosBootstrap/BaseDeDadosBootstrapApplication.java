package bootstrap.baseDeDados.BaseDeDadosBootstrap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseDeDadosBootstrapApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaseDeDadosBootstrapApplication.class, args);
	}

}
