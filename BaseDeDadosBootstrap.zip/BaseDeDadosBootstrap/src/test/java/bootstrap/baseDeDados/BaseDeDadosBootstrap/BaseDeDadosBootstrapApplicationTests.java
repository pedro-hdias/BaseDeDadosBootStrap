package bootstrap.baseDeDados.BaseDeDadosBootstrap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseDeDadosBootstrapApplicationTests {

	@Test
	void contextLoads() {
	}

}
